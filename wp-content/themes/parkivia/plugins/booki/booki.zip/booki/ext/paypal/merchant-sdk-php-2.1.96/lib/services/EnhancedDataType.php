<?php
class EnhancedDataType  
   extends PPXmlMessage{

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var AirlineItineraryType 	 
	 */ 
	public $AirlineItinerary;


   
}