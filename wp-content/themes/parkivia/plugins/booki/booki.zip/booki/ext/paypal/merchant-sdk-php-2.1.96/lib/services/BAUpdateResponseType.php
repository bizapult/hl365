<?php
class BAUpdateResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var BAUpdateResponseDetailsType 	 
	 */ 
	public $BAUpdateResponseDetails;


}