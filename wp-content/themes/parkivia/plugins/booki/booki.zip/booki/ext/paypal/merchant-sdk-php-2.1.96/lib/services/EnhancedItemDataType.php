<?php
class EnhancedItemDataType  
   extends PPXmlMessage{


   
}