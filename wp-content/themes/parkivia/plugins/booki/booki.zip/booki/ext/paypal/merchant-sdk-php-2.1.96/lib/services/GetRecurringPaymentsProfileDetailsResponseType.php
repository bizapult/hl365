<?php
class GetRecurringPaymentsProfileDetailsResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var GetRecurringPaymentsProfileDetailsResponseDetailsType 	 
	 */ 
	public $GetRecurringPaymentsProfileDetailsResponseDetails;


}