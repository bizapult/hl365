<?php
class ErrorParameterType  
   extends PPXmlMessage{

	/**
	 * Value of the application-specific error parameter.  
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var string 	 
	 */ 
	public $Value;


}