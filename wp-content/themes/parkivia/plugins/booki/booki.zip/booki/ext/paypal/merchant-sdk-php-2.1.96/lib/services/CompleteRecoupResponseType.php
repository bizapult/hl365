<?php
class CompleteRecoupResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ed
	 
	 	 	 	 
	 * @var EnhancedCompleteRecoupResponseDetailsType 	 
	 */ 
	public $EnhancedCompleteRecoupResponseDetails;


}