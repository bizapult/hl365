<?php
class EnhancedInitiateRecoupRequestDetailsType  
   extends PPXmlMessage{


   
}