<?php
class BMSetInventoryResponseType  extends AbstractResponseType  
  {


}