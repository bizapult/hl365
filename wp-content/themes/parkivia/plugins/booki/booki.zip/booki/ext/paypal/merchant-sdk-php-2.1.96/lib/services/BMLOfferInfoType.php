<?php
class BMLOfferInfoType  
   extends PPXmlMessage{

	/**
	 * Unique identification for merchant/buyer/offer combo. 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var string 	 
	 */ 
	public $OfferTrackingID;


   
}