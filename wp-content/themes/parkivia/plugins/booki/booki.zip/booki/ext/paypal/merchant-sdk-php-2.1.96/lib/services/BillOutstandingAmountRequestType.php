<?php
class BillOutstandingAmountRequestType  extends AbstractRequestType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var BillOutstandingAmountRequestDetailsType 	 
	 */ 
	public $BillOutstandingAmountRequestDetails;


   
}