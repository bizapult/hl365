<?php
class GetMobileStatusRequestDetailsType  
   extends PPXmlMessage{

	/**
	 * Phone number for status inquiry 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PhoneNumberType 	 
	 */ 
	public $Phone;


   
}