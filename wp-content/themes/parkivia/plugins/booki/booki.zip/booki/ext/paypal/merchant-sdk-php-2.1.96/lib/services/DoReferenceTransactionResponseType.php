<?php
class DoReferenceTransactionResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var DoReferenceTransactionResponseDetailsType 	 
	 */ 
	public $DoReferenceTransactionResponseDetails;

	/**
	 * 
	 * @access public
	 
	 * @namespace ns
	 
	 	 	 	 
	 * @var FMFDetailsType 	 
	 */ 
	public $FMFDetails;


}