<?php
class GetExpressCheckoutDetailsResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var GetExpressCheckoutDetailsResponseDetailsType 	 
	 */ 
	public $GetExpressCheckoutDetailsResponseDetails;


}