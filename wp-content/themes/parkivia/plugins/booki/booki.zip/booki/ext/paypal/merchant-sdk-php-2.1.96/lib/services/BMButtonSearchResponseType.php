<?php
class BMButtonSearchResponseType  extends AbstractResponseType  
  {

	/**
	 * 
     * @array
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var ButtonSearchResultType 	 
	 */ 
	public $ButtonSearchResult;


}