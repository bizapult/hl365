<?php
class DoUATPExpressCheckoutPaymentRequestType  extends DoExpressCheckoutPaymentRequestType  
  {


   
}