<?php
class EnhancedCheckoutDataType  
   extends PPXmlMessage{


   
}