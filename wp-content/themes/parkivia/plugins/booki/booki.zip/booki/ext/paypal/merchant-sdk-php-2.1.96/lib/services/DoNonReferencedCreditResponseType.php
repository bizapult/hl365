<?php
class DoNonReferencedCreditResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var DoNonReferencedCreditResponseDetailsType 	 
	 */ 
	public $DoNonReferencedCreditResponseDetails;


}