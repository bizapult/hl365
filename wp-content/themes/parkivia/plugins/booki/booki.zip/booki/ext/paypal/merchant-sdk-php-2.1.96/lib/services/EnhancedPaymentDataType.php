<?php
class EnhancedPaymentDataType  
   extends PPXmlMessage{


   
}