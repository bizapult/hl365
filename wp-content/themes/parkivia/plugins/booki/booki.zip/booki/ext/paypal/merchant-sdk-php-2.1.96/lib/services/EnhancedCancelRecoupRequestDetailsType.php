<?php
class EnhancedCancelRecoupRequestDetailsType  
   extends PPXmlMessage{


   
}