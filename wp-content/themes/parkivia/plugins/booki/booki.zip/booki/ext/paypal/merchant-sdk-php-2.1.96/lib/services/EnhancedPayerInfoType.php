<?php
class EnhancedPayerInfoType  
   extends PPXmlMessage{


   
}