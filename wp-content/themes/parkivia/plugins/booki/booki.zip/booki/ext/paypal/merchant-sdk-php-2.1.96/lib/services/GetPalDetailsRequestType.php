<?php
class GetPalDetailsRequestType  extends AbstractRequestType  
  {


   
}