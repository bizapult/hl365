<?php
class BMManageButtonStatusResponseType  extends AbstractResponseType  
  {


}