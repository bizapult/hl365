<?php
class EnhancedPaymentInfoType  
   extends PPXmlMessage{


}