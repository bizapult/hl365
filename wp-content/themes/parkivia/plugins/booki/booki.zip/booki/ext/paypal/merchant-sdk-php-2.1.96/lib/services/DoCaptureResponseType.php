<?php
class DoCaptureResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var DoCaptureResponseDetailsType 	 
	 */ 
	public $DoCaptureResponseDetails;


}