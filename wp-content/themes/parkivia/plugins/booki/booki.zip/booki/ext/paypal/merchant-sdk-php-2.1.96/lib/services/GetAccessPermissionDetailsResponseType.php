<?php
class GetAccessPermissionDetailsResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var GetAccessPermissionDetailsResponseDetailsType 	 
	 */ 
	public $GetAccessPermissionDetailsResponseDetails;


}