<?php
class ExternalRememberMeOptOutResponseType  extends AbstractResponseType  
  {


}