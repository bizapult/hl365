<?php
class BillUserResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var MerchantPullPaymentResponseType 	 
	 */ 
	public $BillUserResponseDetails;

	/**
	 * 
	 * @access public
	 
	 * @namespace ns
	 
	 	 	 	 
	 * @var FMFDetailsType 	 
	 */ 
	public $FMFDetails;


}