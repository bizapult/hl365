<?php
class CreateMobilePaymentResponseType  extends AbstractResponseType  
  {


}