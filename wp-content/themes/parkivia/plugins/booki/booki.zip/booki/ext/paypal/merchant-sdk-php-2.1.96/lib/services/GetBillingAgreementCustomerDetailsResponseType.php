<?php
class GetBillingAgreementCustomerDetailsResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var GetBillingAgreementCustomerDetailsResponseDetailsType 	 
	 */ 
	public $GetBillingAgreementCustomerDetailsResponseDetails;


}