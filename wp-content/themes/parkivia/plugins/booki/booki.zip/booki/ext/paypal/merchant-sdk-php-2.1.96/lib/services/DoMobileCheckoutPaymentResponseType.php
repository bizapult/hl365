<?php
class DoMobileCheckoutPaymentResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var DoMobileCheckoutPaymentResponseDetailsType 	 
	 */ 
	public $DoMobileCheckoutPaymentResponseDetails;


}