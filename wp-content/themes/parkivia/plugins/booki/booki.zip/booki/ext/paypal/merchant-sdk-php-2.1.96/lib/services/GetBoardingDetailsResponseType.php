<?php
class GetBoardingDetailsResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var GetBoardingDetailsResponseDetailsType 	 
	 */ 
	public $GetBoardingDetailsResponseDetails;


}