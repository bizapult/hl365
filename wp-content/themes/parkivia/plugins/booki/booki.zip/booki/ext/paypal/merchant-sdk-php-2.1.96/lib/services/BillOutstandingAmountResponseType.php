<?php
class BillOutstandingAmountResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var BillOutstandingAmountResponseDetailsType 	 
	 */ 
	public $BillOutstandingAmountResponseDetails;


}