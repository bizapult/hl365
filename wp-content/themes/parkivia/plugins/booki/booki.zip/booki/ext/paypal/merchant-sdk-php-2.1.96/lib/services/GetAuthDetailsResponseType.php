<?php
class GetAuthDetailsResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var GetAuthDetailsResponseDetailsType 	 
	 */ 
	public $GetAuthDetailsResponseDetails;


}