<?php
class GetIncentiveEvaluationResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var GetIncentiveEvaluationResponseDetailsType 	 
	 */ 
	public $GetIncentiveEvaluationResponseDetails;


}