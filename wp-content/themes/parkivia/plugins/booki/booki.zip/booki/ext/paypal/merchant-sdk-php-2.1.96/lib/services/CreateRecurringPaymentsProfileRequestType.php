<?php
class CreateRecurringPaymentsProfileRequestType  extends AbstractRequestType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var CreateRecurringPaymentsProfileRequestDetailsType 	 
	 */ 
	public $CreateRecurringPaymentsProfileRequestDetails;


   
}