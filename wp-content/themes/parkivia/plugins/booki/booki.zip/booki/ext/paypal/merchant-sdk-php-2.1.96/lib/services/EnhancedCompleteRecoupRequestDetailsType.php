<?php
class EnhancedCompleteRecoupRequestDetailsType  
   extends PPXmlMessage{


   
}