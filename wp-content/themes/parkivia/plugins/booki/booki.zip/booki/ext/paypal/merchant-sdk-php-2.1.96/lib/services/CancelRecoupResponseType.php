<?php
class CancelRecoupResponseType  extends AbstractResponseType  
  {


}