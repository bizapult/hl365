<?php
class CreateRecurringPaymentsProfileResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var CreateRecurringPaymentsProfileResponseDetailsType 	 
	 */ 
	public $CreateRecurringPaymentsProfileResponseDetails;


}