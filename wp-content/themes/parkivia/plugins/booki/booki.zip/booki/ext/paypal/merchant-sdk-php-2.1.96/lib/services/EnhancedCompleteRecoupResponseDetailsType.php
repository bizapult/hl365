<?php
class EnhancedCompleteRecoupResponseDetailsType  
   extends PPXmlMessage{


}