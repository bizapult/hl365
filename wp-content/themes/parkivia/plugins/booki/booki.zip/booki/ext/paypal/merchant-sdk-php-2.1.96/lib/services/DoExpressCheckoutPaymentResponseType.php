<?php
class DoExpressCheckoutPaymentResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var DoExpressCheckoutPaymentResponseDetailsType 	 
	 */ 
	public $DoExpressCheckoutPaymentResponseDetails;

	/**
	 * 
	 * @access public
	 
	 * @namespace ns
	 
	 	 	 	 
	 * @var FMFDetailsType 	 
	 */ 
	public $FMFDetails;


}