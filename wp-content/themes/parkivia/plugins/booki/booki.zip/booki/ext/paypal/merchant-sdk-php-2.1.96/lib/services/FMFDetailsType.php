<?php
class FMFDetailsType  
   extends PPXmlMessage{

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var RiskFilterListType 	 
	 */ 
	public $AcceptFilters;

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var RiskFilterListType 	 
	 */ 
	public $PendingFilters;

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var RiskFilterListType 	 
	 */ 
	public $DenyFilters;

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var RiskFilterListType 	 
	 */ 
	public $ReportFilters;


}